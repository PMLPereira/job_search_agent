# SP Job Tracker 🇧🇷

Automated daily job scanner for Pedro's São Paulo finance career search.
Scrapes target company career pages, scores roles against your CV using Claude AI,
and publishes a live dashboard via GitHub Pages.

## What it does

- **Scans daily** at 7am UTC via GitHub Actions
- **Covers 12 target companies**: BTG Pactual, XP Investimentos, Nubank, Itaú BBA, Pátria Investimentos, Vinci Partners, Bradesco BBI, Santander Brasil, Stone, Warren, Kinea, Avenue Securities
- **AI scores each role** 0–100 against your profile, with match reasons, gaps and tailored talking points
- **Pipeline tracker** with status, contacts and notes (stored in browser localStorage)
- **One-click LinkedIn & Google Alert** setup links

## Setup (5 minutes)

### 1. Create the GitHub repo

```bash
git init sp-job-tracker
cd sp-job-tracker
# copy all these files in
git add .
git commit -m "Initial setup"
git remote add origin https://github.com/YOUR-USERNAME/sp-job-tracker.git
git push -u origin main
```

### 2. Add your Anthropic API key

- GitHub repo → **Settings** → **Secrets and variables** → **Actions**
- Click **New repository secret**
- Name: `ANTHROPIC_API_KEY`
- Value: your API key from console.anthropic.com

### 3. Enable GitHub Pages

- GitHub repo → **Settings** → **Pages**
- Source: **Deploy from a branch**
- Branch: `main` / folder: `/docs`
- Save

### 4. Run the first scan manually

- Go to **Actions** tab → **Daily Job Scan** → **Run workflow**
- Wait ~2 minutes

### 5. Access your dashboard

```
https://YOUR-USERNAME.github.io/sp-job-tracker/
```

Bookmark this. It updates automatically every morning.

## Adding more companies

Edit `COMPANIES` list in `scripts/scan.py`. Most Brazilian companies use Gupy ATS —
find their slug from their careers URL (e.g. `btgpactual.gupy.io` → slug is `btgpactual`).

## Costs

- GitHub Actions: **free** (well within free tier limits)
- Claude API scoring: ~$0.05–0.15 per daily run (20 roles max per run)
- GitHub Pages: **free**

Total: roughly **$1–3/month** in API costs.

## Files

```
.github/workflows/daily-scan.yml   — GitHub Actions cron job
scripts/scan.py                    — main scanner + scorer + HTML generator
requirements.txt                   — Python dependencies
docs/index.html                    — generated dashboard (auto-updated)
docs/data.json                     — job data store (auto-updated)
```
